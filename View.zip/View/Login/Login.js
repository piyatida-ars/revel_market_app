import React from 'react';
import {
   Image,
   StatusBar,
   ScrollView,
   Text,
   TextInput,
   TouchableOpacity,
    View,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

export class Login extends React.Component{
    constructor(props){
        super(props)

    }

    componentDidMount(){

    }

    render(){
        return(

            <ScrollView style={{ backgroundColor:"#010001",}}>
            <StatusBar hidden={true}/>
            <View styles={{padding:36,}}>
            <Image resizeMode="contain"  source={require('../../images/logo.png')}
            style={{width:200,height:200,marginTop:54,marginBottom:24,alignSelf:'center'}}></Image>
            <View styles={[styles.row_underline, {maginBotton:16}]}>
              <Icon name="email-outline" style={styles.login_icon} />
                <TextInput placeholder="Email address"
                            placeholderTextColor="#ADADAD"
                            underlineColorAndroid='transparent'
                            style={{color: '#fff',flex:1,fontSize:16,paddingLeft:12,}}
            />
            </View>
            <View style={[styles.row_underline,{marginBottom:24,}]}>
                <Icon name="lock-outline" style={styles.login_icon}/>
                <TextInput placeholder="Password"
                            placeholderTextColor="#ADADAD"
                            underlineColorAndroid='transparent'
                            style={{color:'#fff',flex:1,fontSize:16,paddingLeft:12,}}
                            secureTextEntry={true}
             />
             </View>
                <TouchableOpacity style={{flex:1,backgroundColor:'#25aae1',borderRadius:2,padding:10,}}>
                    <Text style={{alignSelf:"center",fontSize:16,color:'#fff',}}>LOGIN</Text>
                </TouchableOpacity>
            </View>
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
   row_underline:{
    flexDirection: "row",
    borderBottonWidth: 1,
    borderBottonWidth: '#b6b6b6',

   },
    login_icon:{
        alignSelf: 'center',
        fontSize: 20,
        color: '#ADADAD'
    },
    });